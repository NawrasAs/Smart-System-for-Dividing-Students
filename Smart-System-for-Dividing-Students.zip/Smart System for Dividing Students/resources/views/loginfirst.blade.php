
  @extends('partials.master')

  @section('content')

  @endsection
