

	@extends('student.master')

	@section('content')

		<hr style="border-color: mediumseagreen;">

		<hr><h2 class="text-primary">About Us</h2><hr>
		<p class="text-white"> In this site we generally helps the person to improve their skill in various format. By this they can give online test base on selected subject and selected topics. Mcq and written question are generated/outhorised by the honarable teachers. Result are also given instantly by checking. Overall ranking are also given based on the total result </p>

		<p class="text-white">There are many modarator,teachers from various top rated university worked as judge here. they set the question and justify the answer. Enamul Hasan ,lecturar,dept of cse(SUST) are the Head of the Modaration control board.He gives the update for upcoming days</p>
		<br><br>
		<hr><h2 class=" text-primary">Developers</h2><hr>
		<p class="text-white">To make this site and mantain the whole project two developer worked here.They worked as team  and try to make it simple.The Team leader is Asadullah_Galib. By his leadership this was an nightmare experiance. </p>
		<p class="text-white">INfo about them:</p><br>

		<p class="text-success">Asadullah_Galib</p>
		   <p class="text-white">Team leader,Dept of Cse,SEC </p>
		   <p class="text-white">Email: <a href="#">asadullahgalib@gamil.com</a></p>
		<br>
		<p class="text-success">Aashraful_Hridoy</p>
		   <p class="text-white">Dept of Cse,SEC </p>
		   <p class="text-white mb-4">Email: <a href="#">aashrafulhridoy@gmail.com</a></p>

			@endsection
