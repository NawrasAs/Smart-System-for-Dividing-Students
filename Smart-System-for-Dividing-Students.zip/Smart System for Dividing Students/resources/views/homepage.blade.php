<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="{{asset('https://use.fontawesome.com/releases/v5.4.2/css/all.css')}}">
    <link rel="stylesheet" href="{{asset('css/bootstrap.css')}}">
    <link rel="stylesheet" href="{{asset('css/fonts.css')}}">
    <link rel="stylesheet" href="{{asset('fonts/fonts.css')}}">
    <link rel="stylesheet" href="{{asset('css/test.css')}}">
    <link rel="stylesheet" href="{{asset('css/style.css')}}">
    <link rel="stylesheet" href="{{asset('css/parsley.css')}}">
    <script type="text/javascript" src="{{asset('js/bootstrapjquery.js')}}"></script>
    <script type="text/javascript" src="{{asset('js/parsley.min.js')}}"></script>
    <script type="text/javascript" src="{{asset('js/popper.js')}}"></script>
    <script type="text/javascript" src="{{asset('js/bootstrap.js')}}"></script>

    <title>Questionnaire Management System</title>
    <link rel="icon" type="icon" href="{{asset('icon/exam.png')}}">
</head>

<body style="background-color: whitesmoke;">

    <div class="container">
        <br>

        <!-- Navbar Started Hare -->

        <nav class="navbar navbar-expand-md sticky-top navbar-light bg-success rounded">

            <button class="navbar-toggler" data-toggle="collapse" data-target="#target">
                <span class="navbar-toggler-icon"></span>
            </button>

            <a class="navbar-brand" href="{{route('student')}}"><img src="{{asset('icon/exam.png')}}" style="height: 55px;"></a>

            <div class="collapse navbar-collapse" id="target">
                <ul class="navbar-nav mx-auto">
                    <li class="nav-item">
                        <a href="{{route('student')}}" class="nav-link btn-outline-info rounded text-white pr-3">HOME</a>
                    </li>

                    <li class="nav-item d-none">
                        <a href="{{route('about')}}" class="nav-link btn-outline-info rounded text-white pr-3">ABOUT</a>
                    </li>

                    <li class="nav-item dropdown">
                        <a href="#" class="nav-link dropdown-toggle btn-outline-info rounded text-white" data-toggle="dropdown" data-target="dropdown_target pr-3">QUESTIONNAIRE  SCHEDULE</a>

                        <div class="dropdown-menu bg-info" aria-labelledby="dropdown_target">
                            <a class="dropdown-item text-white" href="{{route('upcomingHome')}}">Upcoming Exam</a>
                            <a class="dropdown-item text-white" href="{{route('ongoingHome')}}">Ongoing Exam</a>
                            <a class="dropdown-item text-white" href="{{route('previousHome')}}">Previous Exam</a>

                        </div>

                    </li>

                    <li class="nav-item">
                        <a href="{{route('noticeHome')}}" class="d-none nav-link btn-outline-info rounded text-white pr-3">NOTICE BOARD</a>
                    </li>

                    <li class="nav-item dropdown d-none">
                        <a href="#" class="nav-link dropdown-toggle btn-outline-info rounded text-white" data-toggle="dropdown" data-target="dropdown_target pr-3">CONTACT US</a>

                        <div class="dropdown-menu bg-info" aria-labelledby="dropdown_target">
                            <a href="{{route('viaEmail')}}" class="dropdown-item text-white"><i class="far fa-envelope"></i> Via Email</a>
                            <a href="{{route('viaMessenger')}}" class="dropdown-item text-white"><i class="fab fa-facebook-messenger"></i> Via Messenger</a>
                            <a href="{{route('viaPhone')}}" class="dropdown-item text-white"><i class="fas fa-phone-volume"></i> Via Phone Call</a>
                        </div>

                    </li>

                    <li class="nav-item dropdown">
                        <a href="#" class="nav-link dropdown-toggle btn-outline-info rounded text-white pr-3" data-toggle="dropdown">REGISTER</a>

                        <div class="dropdown-menu bg-info divide">
                            <a href="{{route('teacher')}}" class="dropdown-item text-white">Teacher</a>
                            <a href="{{route('student')}}" class="dropdown-item text-white">Student</a>
                        </div>
                    </li>

                    <li class="nav-item dropdown">
                        <a href="#" class="nav-link dropdown-toggle btn-outline-info rounded text-white pr-3" data-toggle="dropdown">LOGIN</a>

                        <div class="dropdown-menu bg-info divide">
                            <a href="{{route('teacherLogin')}}" class="dropdown-item text-white">Teacher</a>
                            <a href="{{route('studentLogin')}}" class="dropdown-item text-white">Student</a>
                        </div>
                    </li>

                    <!--LOGIN DISABLED
          <li class="nav-item">
            <a href="#" class="nav-link btn-outline-info rounded text-white pr-4">LOGIN</a>
          </li>

        -->

                </ul>

                <!-- Search Box -->

                <ul class="navbar-nav ml-auto d-none">
                    <form>
                        <div class="input-group">
                            <input class="form-control" type="text" name="search" placeholder="Search">
                            <div class="input-group-btn">
                                <button class="btn btn-info" style="width: 50px;" type="submit"><i class="fas fa-search"></i></button>
                            </div>
                        </div>
                    </form>
                </ul>

                <!--End-->
            </div>

        </nav>

        <!-- Navbar End Hare -->

        <!--Login End-->

        <hr style="border-color: mediumseagreen;">

        <!--Login Starts -->

        <div class="row mb-3">

            <!--First Half-->
            <div class="col-md-7 col-sm-8 col-lg-7 ">
                <div class="row">
                  <?php $i=1;
                        $es = \App\Relation\ExamDetail::latest()->take(4)->get();
                   ?>
                    @foreach($es as $e)
                    <div class="col-sm-11 col-md-6 col-lg-6 mt-1 mb-3">
                        <div class="card-deck">
                            <!--Upcoming Questionnaire Cards-->
                            <div class="card " style="width: 15rem; background-color: #26a69a;">
                                <img class="card-img-top ml-5" src="{{asset('icon/exam.png')}}" style="height: 60px; width: 60px;" alt="Card image cap">
                                <div class="card-body">
                                    <h6 class="card-title text-uppercase">Questionnaire title: <span style="color: #e0f2f1;">{{$e->examtitle}}</span></h6>
                                    <ul>
                                        <li class="card-text">Questionnaire date: {{$e->examdate}}</li>
                                        <li class="card-text">Questionnaire time: {{$e->examtime}}</li>
                                        <li class="card-text">Total marks: {{$e->marks}}</li>
                                    </ul>
                                    <div class="row ml-auto">
                                      <div class="text center mr-2">COUNTDOWN: <span> </span> </div>
                                      <h5 class="text- text-center" style="color: #bf360c;" id="demo{{$i++}}"></h5>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    @endforeach
                </div>

                <!--Ongoing Questionnaire Cards-->
                <!--	 <div class="card" style="width: 15rem; background-color: #80deea;">
						<!--	 <div class="card" style="width: 15rem; background-color: #80deea;">
						<!--	 <div class="card" style="width: 15rem; background-color: #80deea;">
					 <img class="card-img-top ml-5" src="{{asset('icon/exam.png')}}" style="height: 100px; width: 100px;" alt="Card image cap">
					 <div class="card-body">
						 <h5 class="card-title">Card title</h5>
						 <p class="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
						 <a href="#" class="btn btn-primary">Go somewhere</a>
					 </div>
				 </div> -->

                <!-- CARDS Ends -->

            </div>

            <!--Second Half-->
            <div class="col-md-5 col-sm-4 mb-3 col-lg-5">
                <form class="form-container" style="float: " method="post" action="/homepagelogin">

                    @if(session('f'))
                    <div class="alert alert-danger">
                        <p>Wrong Email or Password</p>
                    </div>
                    @endif @csrf

                    <h2 class="text-success text-uppercase text-center">
										 <img class="pb-2 pr-2" src="{{asset('icon/exam.png')}}" style="height: 55px;"> Login
										</h2>

                    <div class="form-group">
                        <label for="exampleInputEmail1" class="text-success">Email</label>
                        <input type="email" name="email" class="form-control" id="exampleInputEmail1" placeholder="Email" style="height: 35px;">
                    </div>

                    <div class="form-group">
                        <label for="exampleInputPassword1" class="text-success">Password</label>
                        <input type="password" name="password" class="form-control" id="exampleInputPassword1" placeholder="Password" style="height: 35px;">
                    </div>

                    <div class="mb-3">
                        <label for="teacher-student" class="text-success" style="height: 35px;">Student/Teacher</label>
                        <select id="gender" name="type" class="form-control">
                            <option selected value="s">Student</option>
                            <option value="t">Teacher</option>
                        </select>
                    </div>

                    <div class="checkbox">
                        <label class="text-success">
                            <input type="checkbox"> Remember Me
                        </label>
                    </div>

                    <button type="submit" class="btn btn-success btn-block">Submit</button>
                </form>
            </div>

            <div class="col-md-0 col-sm-0 col-lg-0 "></div>
        </div>
    </div>

    <div class="container mb-2 ">
        <hr style="border-color: mediumseagreen;">
        <div class="footer">
            <ul class="nav nav-pills nav-fill bg-success rounded">
                <li class="nav-item">
                    <a href="#" class="nav-link text-white btn-outline-info"><i class="far fa-copyright"></i> Copyright</a>
                </li>
            </ul>
            <hr>
        </div>
    </div>

</body>
<script>
    // Set the date we're counting down to
    var countDownDate0 = {{$es[0]->starts}}*1000;;

    // Update the count down every 1 second
    var x = setInterval(function() {

        // Get todays date and time
        var now = new Date().getTime();

        // Find the distance between now and the count down date
        var distance = countDownDate0 - now;

        // Time calculations for days, hours, minutes and seconds
        var days = Math.floor(distance / (1000 * 60 * 60 * 24));
        var hours = Math.floor((distance % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
        var minutes = Math.floor((distance % (1000 * 60 * 60)) / (1000 * 60));
        var seconds = Math.floor((distance % (1000 * 60)) / 1000);

        // Display the result in the element with id="demo"
        document.getElementById("demo1").innerHTML = days + "d " + hours + "h " + minutes + "m " + seconds + "s ";

        // If the count down is finished, write some text
        if({{$es[0]->ends}}*1000<now && {{$es[0]->starts}}*1000<now){
          document.getElementById("demo1").innerHTML = "RUNNING";
        }

        else if (distance < 0) {
            clearInterval(x);
            document.getElementById("demo1").innerHTML = "FINISHED";
        }
    }, 1000);
</script>

<script>
    // Set the date we're counting down to
    var countDownDate1 = {{$es[1]->starts}}*1000;;

    // Update the count down every 1 second
    var p = setInterval(function() {

        // Get todays date and time
        var now = new Date().getTime();

        // Find the distance between now and the count down date
        var distance = countDownDate1 - now;

        // Time calculations for days, hours, minutes and seconds
        var days = Math.floor(distance / (1000 * 60 * 60 * 24));
        var hours = Math.floor((distance % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
        var minutes = Math.floor((distance % (1000 * 60 * 60)) / (1000 * 60));
        var seconds = Math.floor((distance % (1000 * 60)) / 1000);

        // Display the result in the element with id="demo"
        document.getElementById("demo2").innerHTML = days + "d " + hours + "h " + minutes + "m " + seconds + "s ";

        if({{$es[1]->ends}}*1000>now && {{$es[1]->starts}}*1000<now){
          document.getElementById("demo2").innerHTML = "RUNNING";
        }
        // If the count down is finished, write some text
        else if (distance < 0) {
            clearInterval(x);
            document.getElementById("demo2").innerHTML = "FINISHED";
        }
    }, 1000);
</script>

<script>
    // Set the date we're counting down to
    var countDownDate2 = {{$es[2]->starts}}*1000;

    // Update the count down every 1 second
    var z = setInterval(function() {

        // Get todays date and time
        var now = new Date().getTime();

        // Find the distance between now and the count down date
        var distance = countDownDate2 - now;

        // Time calculations for days, hours, minutes and seconds
        var days = Math.floor(distance / (1000 * 60 * 60 * 24));
        var hours = Math.floor((distance % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
        var minutes = Math.floor((distance % (1000 * 60 * 60)) / (1000 * 60));
        var seconds = Math.floor((distance % (1000 * 60)) / 1000);

        // Display the result in the element with id="demo"
        document.getElementById("demo3").innerHTML = days + "d " + hours + "h " + minutes + "m " + seconds + "s ";

        if({{$es[2]->ends}}*1000>now && {{$es[2]->starts}}*1000<now){
          document.getElementById("demo3").innerHTML = "RUNNING";
        }
        // If the count down is finished, write some text
        else if (distance < 0) {
            clearInterval(x);
            document.getElementById("demo3").innerHTML = "FINISHED";
        }
    }, 1000);
</script>

<script>
    // Set the date we're counting down to
    var countDownDate3 = {{$es[3]->starts}}*1000;

    // Update the count down every 1 second
    var y = setInterval(function() {

        // Get todays date and time
        var now = new Date().getTime();

        // Find the distance between now and the count down date
        var distance = countDownDate3 - now;
        console.log(distance);

        // Time calculations for days, hours, minutes and seconds
        var days = Math.floor(distance / (1000 * 60 * 60 * 24));
        var hours = Math.floor((distance % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
        var minutes = Math.floor((distance % (1000 * 60 * 60)) / (1000 * 60));
        var seconds = Math.floor((distance % (1000 * 60)) / 1000);

        // Display the result in the element with id="demo"
        document.getElementById("demo4").innerHTML = days + "d " + hours + "h " + minutes + "m " + seconds + "s ";

        if({{$es[3]->ends}}*1000>now && {{$es[3]->starts}}*1000<now){
          document.getElementById("demo4").innerHTML = "RUNNING";
        }
        // If the count down is finished, write some text
        else if (distance < 0) {
            clearInterval(x);
            document.getElementById("demo4").innerHTML = "FINISHED";
        }
    }, 1000);
</script>

</html>

<!--Footer-->
