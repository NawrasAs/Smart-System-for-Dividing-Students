@extends('student.master')
@section('content')

<hr style="border-color: mediumseagreen;">
<h3 class="text-success mt-5">Intro:</h3><hr style="border-color: white;">

<p class="text-white">There are many modarator,teachers from various top rated university worked as judge here. they set the question and justify the answer. Enamul Hasan ,lecturar,dept of cse(SUST) are the Head of the Modaration control board.He gives the update for upcoming days</p>
<br>
<hr><h2 class="text-success">Modarator</h2><hr>
<p class="text-white">
	The honarable teacher updates their status based on exam.they set the questions and gives the instraction about the exam.the modaration board are:
</p>
<p class="text-white">Enamul Hasan</p>
<p class=" text-white">Head of modaration board,Dept of CSE,SUST </p>
<p class=" text-white">Contact: 01627598854</p>
   <p class=" text-white">Email: <a href="#">Enamulhasan@gamil.com</a></p><br>

   <p class=" text-white">Abu Naser Majumder </p>
   <p class=" text-white">Associate prof. Dept of CSE,SEC </p>
   <p class=" text-white">Contact: 01965267745</p>
   <p class=" text-white">Email: <a href="#">abunasermajumder@gamil.com</a></p>

<hr><h2 class=" text-success">Developers</h2><hr>
<p class=" text-white">To make this site and mantain the whole project two developer worked here.They worked as team  and try to make it simple.The Team leader is Asadullah_Galib. By his leadership this was an nightmare experiance. </p>
<p class=" text-white">INfo about them:</p><br>

<p class=" text-white">Asadullah_Galib</p>
   <p class=" text-white">Team leader,Dept of CSE,SEC </p>
   <p class=" text-white">Email: <a href="#">asadullahgalib@gamil.com</a></p>
<br>
<p class=" text-white">Aashraful_Hridoy</p>
   <p class=" text-white">Dept of CSE,SEC </p>
   <p class=" text-white mb-5">Email: <a href="#">aashrafulhridoy@gmail.com</a></p>


@endsection
