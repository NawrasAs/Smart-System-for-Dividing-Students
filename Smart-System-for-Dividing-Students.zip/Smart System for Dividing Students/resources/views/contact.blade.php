@extends('partials.master')

@section('content')
<div>

	<hr><h2 style="color:black !important;">Contact Page</h2>

</div>
@endsection
