

	@extends('teacher.master')

	@section('content')

		

		<h3 class="m-5" style="color: mediumseagreen;"> Copyright </h3>


		<p class="m-5 text-white">Copyright © 2019 Questionnaire management system BD, Inc. All rights reserved. <a href="#">Terms of Use</a> | <a href="#">Privacy Policy-REVISED</a>   1-846-exam management system (1-846-735-4648)</p>
	</div><br><br><br><br><br><br><br><br><br><br><br><br>


@endsection
