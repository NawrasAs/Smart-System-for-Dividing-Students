
	@extends('teacher.master')

	@section('content')
	

	<div style="color:black !important>
		<p class="text-white">
			Exam_Management_System<br>
			+8801625637753 <br>
			exammanagement@gmail.com

		</p>

		<p class="text-white">
			Work/Internships<br>
			workhours :10am-10pm
		</p>

		<hr><h2 class="text-success">Tell us about your dream....</h2><hr>

		<h4 class="text-success">visit us</h4>
		<p class="text-white">via postal code<br>
			3100 Sylhet,Bangladesh
		</p>

		<h5 class="text-success">legal info</h5>
		<p class="text-white mb-5">
			<br>
			via- +92 307 6069 760

		</p>

	</div>

@endsection
