
@extends('partials.master')

		<!-- Navbar End Hare -->
@section('content')

<hr style="border-color: mediumseagreen;">
<div>
		<div >
			<h3 class="text-success text-center mt-5">CONTACT US</h3>
			<p class="text-white text-center ">There is a simple way to contact us and get in the touch of us.</p>
		</div>
	</div>
	<br>
<div class="row my-5">
		<div class="col-4">
	    	<div class="tab-pane fade show text-success" id="Home" role="tabpanel"><h4>Phone:</h4></div>
	    	<div class="tab-pane fade show text-primary" id="About" role="tabpanel">+8801625637753</div>
	    	<div class="tab-pane fade show text-white" id="About" role="tabpanel text-primary">Saturday-thusday</div>
	    	<div class="tab-pane fade show text-danger" id="About" role="tabpanel">(10.00AM-5.30 PM)</div>
	    </div>

	  <div class="col-4">
	    	<div class="tab-pane fade show text-success" id="Home" role="tabpanel"><h4>Corporate Office:</h4></div>
	    	<div class="tab-pane fade show  text-white" id="About" role="tabpanel">SEC,Alutol,Tilagor</div>
	    	<div class="tab-pane fade show text-white" id="About" role="tabpanel">Tilagor,Sylhet-3100</div>
	    	<div class="tab-pane fade show text-primary" id="About" role="tabpanel">+8801521311155</div>
	    	<div class="tab-pane fade show text-white" id="About" role="tabpanel">Saturday-thusday</div>
	    </div>
		<div class="col-4">
	    	<div class="tab-pane fade show text-success" id="Home" role="tabpanel"><h4>Executive Officer:</h4></div>
	    	<div class="tab-pane fade show  text-primary" id="About" role="tabpanel">Asadullah_Galib</div>
	    	<div class="tab-pane fade show text-white" id="About" role="tabpanel text-primary">Housing State,Amborkhana,sylhet</div>
	    	<div class="tab-pane fade show text-white" id="About" role="tabpanel text-primary">+880152131166</div>
	    	<div class="tab-pane fade show text-primary" id="About" role="tabpanel">Email:<a href="#">asadullahpranto@gmail.com</a></div>
	    </div>
	</div>


<br><br><br><br><br>
</div>



				</div>

			</div>
		</div>

	</div>

	<!--Footer-->
@endsection
