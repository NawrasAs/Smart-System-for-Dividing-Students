
@extends('partials.master')

		<!-- Navbar End Hare -->
@section('content')

<hr style="border-color: mediumseagreen;">
	<div class="card bg-info text-white">
		<div>
			<b><h2 class="text-center mt-5 sticky-top" style="color:red">Text Us</h2></b>
			<p class="text-center text-white">Get the link below and feel free to message us at for any kind of informaton and to touch with the next event.</p>
		</div>
	</div>
	<br>
	<div class="row my-5 text-center">
		<div class="col-6">
	    	<div class="tab-pane fade show text-success" id="Home" role="tabpanel"><h4>Office:</h4></div>
	    	<div class="tab-pane fade show text-primary" id="About" role="tabpanel">Facebook-<a href="#"> examstm fb </a></div>
	    	<div class="tab-pane fade show text-primary" id="About" role="tabpanel">whatsapp-<a href="#"> examstm whtapp </a></div>
	  	    <div class="tab-pane fade show text-primary" id="About" role="tabpanel">linkedin-<a href="#"> examstm Li </a></div></div>



	  <div class="col-6 text-center">
	    	<div class="tab-pane fade show text-success" id="Home" role="tabpanel"><h4>Others:</h4></div>
	    	<div class="tab-pane fade show text-primary" id="About" role="tabpanel">skype-<a href="#"> examstm skype </a></div>
	    	<div class="tab-pane fade show text-primary" id="About" role="tabpanel">twitter-<a href="#"> examstm twt </a></div>



		</div>
	</div>


<br><br><br><br><br>
</div>



				</div>

			</div>
		</div>

	</div>

	<!--Footer-->
@endsection
