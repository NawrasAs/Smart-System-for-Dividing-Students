<div class="container my-4 ">
  <hr style="border-color: mediumseagreen;">
  <div class="footer">
    <ul class="nav nav-pills nav-fill bg-success rounded">
      <li class="nav-item">
        <a href="#" class="nav-link text-white btn-outline-info"><i class="far fa-copyright"></i> Copyright</a>
      </li>
    </ul><hr>
  </div>
</div>


</body>
</html>
