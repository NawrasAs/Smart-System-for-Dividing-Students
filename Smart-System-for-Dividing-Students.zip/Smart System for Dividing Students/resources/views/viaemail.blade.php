
@extends('partials.master')

		<!-- Navbar End Hare -->
@section('content')

<hr style="border-color: mediumseagreen;">

		<div class="container">
			<div class="row">
				<div class="col-3 col-sm-5 col-xs-6 col-md-3 rounded-left bg-info">
					<ul class="list-unstyled mt-5">
            <li>
              <i class="fas fa-flag-checkered text-white text-center"></i>
              <i class="fas fa-flag-checkered text-white text-center"></i>
              <i class="fas fa-flag-checkered text-white text-center"></i>
              <i class="fas fa-flag-checkered text-white text-center"></i>
              <i class="fas fa-flag-checkered text-white text-center"></i>
              <i class="fas fa-flag-checkered text-white text-center"></i>
            </li>
						<li><hr style="border-color: white;">
							<a href="#" class="text-white ml-2" style="text-decoration: none;">NOTICE BOARD</a>
						</li><hr style="border-color: white;">
					</ul>
				</div>

				<div class="col-9 col-sm-7  col-xs-6 col-md-9 rounded-right" style="background-color: #cfd8dc;">

          <div class="container">
	<div class="card bg-info mt-3">
		<div>
			<b><h2 class="text-center my-5 sticky-top" style="color:tomato">Email US</h2></b>
			<b><p class="text-center text-white">Save your time and Email us in any problem or further purpose.</p></b>
		</div>
	</div>
	<br>

<div class="row my-5">
		<div class="col-4">
	    	<div class="tab-pane fade show text-success" id="Home" role="tabpanel"><h4>Office:</h4></div>
	    	<div class="tab-pane fade show" id="About" role="tabpanel"><a href="#">abcd@gmail.com</a></div>
	    	<div class="tab-pane fade show" id="About" role="tabpanel"><a href="#">management@hotline.com</a></div>
    </div>


	  <div class="col-4">
	    	<div class="tab-pane fade show text-success" id="Home" role="tabpanel"><h4>Executive Officer:</h4></div>
	    	<div class="tab-pane fade show" id="About" role="tabpanel">Asadullah Galib:</div>
	    	<div class="tab-pane fade show" id="About" role="tabpanel"><a href="#">asadullahgalib2gmail.com</a></div>
    </div>

    <div class="col-4">
	    	<div class="tab-pane fade show text-success" id="Home" role="tabpanel"><h4>Modarator</h4></div>
	    	<div class="tab-pane fade show" id="About" role="tabpanel">Enamul Hasan:</div>
	    	<div class="tab-pane fade show" id="About" role="tabpanel"><a href="#">enam420@gmail.com</a></div>
	  </div>

</div><br><br><br><br><br>
</div>



				</div>

			</div>
		</div>

	</div>

	<!--Footer-->
@endsection
