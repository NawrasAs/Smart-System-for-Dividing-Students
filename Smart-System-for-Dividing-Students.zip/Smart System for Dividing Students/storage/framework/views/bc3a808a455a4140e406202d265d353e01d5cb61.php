<?php $__env->startSection('content'); ?>


		<!-- Navbar End Hare -->
    <hr style="border-color: mediumseagreen;">

		<div class="container">
			<div class="row">
				<div class="col-3 col-sm-5 col-xs-6 col-md-3 rounded-left bg-info">
					<ul class="list-unstyled mt-5">
            <li>
              <i class="fas fa-graduation-cap text-white"></i>
              <i class="fas fa-graduation-cap text-white"></i>
              <i class="fas fa-graduation-cap text-white"></i>
              <i class="fas fa-graduation-cap text-white"></i>
              <i class="fas fa-graduation-cap text-white"></i>
              <i class="fas fa-graduation-cap text-white"></i>
            </li><hr style="border-color: white;">
						<li>
							<a href="#" class="text-white" style="text-decoration: none;">UPCOMING EXAM</a>
						</li><hr style="border-color: white;">


					</ul>
				</div>

				<div class="col-9 col-sm-7  col-xs-6 col-md-9 rounded-right" style="background-color: #cfd8dc;">

					<div class="mt-3">
						<h6 class="text-primary">Home / <span class="text-white">Upcoming Questionnaire List</h6>
						<hr>
					</div>

					<div>
						<h3 class="text-info mb-3">Upcoming Questionnaire Lists</h3>
					</div>

					<!--Table -->

					<table class="table table-responsive-sm table-striped table-bordered">
						<thead class="table-success">
							<tr>
								<th>No.</th>
								<th>Questionnaire Title</th>
								<th>Questionnaire Date</th>
								<th>Questionnaire Time</th>
                <th>Marks</th>
							</tr>
						</thead>

						<tbody>
              <?php $i=1 ?>
              <?php $__currentLoopData = $es; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $e): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<tr>
								<td scope="row"><?php echo e($i); ?></td>
								<td><?php echo e($e->examtitle); ?></td>
								<td><?php echo e($e->examdate); ?></td>
								<td><?php echo e($e->examtime); ?></td>
                <td><?php echo e($e->marks); ?></td>
                <?php $i++ ?>
							</tr>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						</tbody>
					</table><hr><br><br><br><br><br><br><br>

				</div>

			</div>
		</div>

	</div>

	<!--Footer-->
	<?php $__env->stopSection(); ?>

<?php echo $__env->make('partials.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/zain/Online-Exam-Management-System/resources/views/upcomingHome.blade.php ENDPATH**/ ?>