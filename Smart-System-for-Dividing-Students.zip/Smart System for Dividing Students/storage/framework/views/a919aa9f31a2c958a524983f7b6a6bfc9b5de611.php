	

	<?php $__env->startSection('content'); ?>


<div style="color:black !important>
		<p class="text-white">
			Exam_Management_System<br>
			+8801625637753 <br>
			exammanagement@gmail.com

		</p>

		<p class="text-white">
			Work/Internships<br>
			workhours :10am-10pm
		</p>

		<hr><h2 class="text-success">Contact</h2><hr>

		<h4 class="text-success">visit us</h4>
		<p class="text-white">via postal code<br>
			3100 Sylhet,Bangladesh
		</p>

		<h5 class="text-success">legal info</h5>
		<p class="text-white mb-5">
			<br>
			via- +92 307 6069 760

		</p>

	</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('student.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/zain/Online-Exam-Management-System/resources/views/foot-s/cos.blade.php ENDPATH**/ ?>