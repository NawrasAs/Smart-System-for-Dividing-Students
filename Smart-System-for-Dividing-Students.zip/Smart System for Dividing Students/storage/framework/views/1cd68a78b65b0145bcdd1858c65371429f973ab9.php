<?php $__env->startSection('content'); ?>
<div class="container">
<div class="row">

  <!--First Column -->

  <div class="col-3 col-sm-5 col-xs-6 col-md-3 rounded-left bg-info">
    <ul class="list-unstyled mt-5">
      <li>
        <a href="<?php echo e(route('teacherdash')); ?>" class="text-white" style="text-decoration: none;"><i class="fas fa-home"></i> DASHBOARD</a>
      </li><hr style="border-color: white;">
      <li>
        <a href="#" class="text-white dropdown-toggle" data-toggle="dropdown" rule="button" style="text-decoration: none;"><i class="fab fa-accusoft"></i> Questionnaires   INFO</a>

        <ul class="dropdown-menu bg-success">
          <li class="dropdown-item"><a href="<?php echo e(route('examlistTeacher')); ?>" class="dropdown-link text-white" style="text-decoration: none;">Questionnaire List</a></li>
          <li class="dropdown-item"><a href="<?php echo e(route('examname')); ?>" class="dropdown-link text-white" style="text-decoration: none;">Create Questionnaire</a></li>
          <li class="dropdown-item"><a href="<?php echo e(route('examtrash')); ?>" class="dropdown-link text-white" style="text-decoration: none;">Questionnaire Trash</a></li>
        </ul>
      </li><hr style="border-color: white;">

      <li>
        <a href="#" class="text-white dropdown-toggle" data-toggle="dropdown" rule="button" style="text-decoration: none;"><i class="fas fa-user"></i> STUDENT INFO</a>

        <ul class="dropdown-menu bg-success">
          <li class="dropdown-item"><a href="<?php echo e(route('studentno')); ?>" class="dropdown-link text-white" style="text-decoration: none;">Student List</a></li>
          <li class="dropdown-item"><a href="/examlistforrank" class="dropdown-link text-white" style="text-decoration: none;">Student Group</a></li>
        </ul>
      </li><hr style="border-color: white;">
      <li class="d-none">
        <a href="#" class="text-white dropdown-toggle" data-toggle="dropdown" rule="button" style="text-decoration: none;"><i class="fas fa-download"></i> EXPORT IMPORT</a>

        <ul class="dropdown-menu bg-success">
          <li class="dropdown-item"><a href="/exportquestion" class="dropdown-link text-white" style="text-decoration: none;">Export Question</a></li>
          <li class="dropdown-item"><a href="<?php echo e(route('export')); ?>" class="dropdown-link text-white" style="text-decoration: none;">Export Result</a></li>
          <li class="dropdown-item"><a href="<?php echo e(route('import')); ?>" class="dropdown-link text-white" style="text-decoration: none;">Import Exam</a></li>
        </ul>
      </li>
    </ul>
  </div>

  <!-- First Column End -->


  <!-- Second Column Starts -->

  <div class="col-9 col-sm-7  col-xs-6 col-md-9 rounded-right" style="background-color: #cfd8dc;">

    <div class="mt-3">
      <h6 class="text-primary">Home / <span class="text-white">Create Questionnaire</h6>
      <hr>
    </div>

    <div class="container" style="background-color: #cfd8dc;">
      <h4 class="text-uppercase text-center my-3 text-info">Questionnaire Title: <?php echo e($e->examtitle); ?></h4>
      <div class="row">
        <div class="col-md-4 col-lg-4">
            <div class="text-center"><b>Questionnaire Date: <?php echo e($e->examdate); ?></b></div>
        </div>
        <div class="col-md-4">
            <div class="text-center"><b>Total Time: <?php echo e($e->totaltime); ?> min</b></div>
        </div>
        <div class="col-md-4">
            <div class="text-center"><b>Full Marks: <?php echo e($e->marks); ?></b></div>
        </div>
      </div><br>
      <div style="float: right;">
        <div class="btn btn-outline-info btn-sm mr-1">
          <a href="/editexamdetail/<?php echo e($e->id); ?>"  style="text-decoration: none;">Edit</a>
        </div>
        <div class="btn btn-outline-info btn-sm">
          <a href="/deleteexamdetail/<?php echo e($e->id); ?>"  style="text-decoration: none;">Delete</a>
        </div>
      </div><br><hr>

      <?php  $i=1;   ?>

      <?php $__currentLoopData = $qs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $q): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <lebel for="question"><?php echo e($i); ?>. <?php echo e($q->question); ?></lebel>

      <?php $i++;  ?>
      <div class="row my-2 clearfix">
        <div class="col-5 ml-5">A. <?php echo e($q->a); ?></div>
        <div class="col-5">B. <?php echo e($q->b); ?></div>
      </div>

      <div class="row mb-3 my-2">
        <div class="col-5 ml-5">C. <?php echo e($q->c); ?></div>
        <div class="col-5">D. <?php echo e($q->d); ?></div>
      </div>
      <div>
        <div class="ml-5">Answer: <?php echo e($q->answer); ?></div>
      </div>
      <div style="float: right">
        <div class="btn btn-outline-info btn-sm mr-1">
          <a href="/editquestion/<?php echo e($q->id); ?>"  style="text-decoration: none;">Edit</a>
        </div>
        <div class="btn btn-outline-info btn-sm">
          <a href="/deletequestion/<?php echo e($q->id); ?>"  style="text-decoration: none;">Delete</a>
        </div>
      </div>
      <div class="clearfix">

      </div>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      <div class="text-center">
        <button type="submit" class="btn btn-outline-info btn-sx mr-2 mb-5 mt-3" style="width: 150px;"><a href="/addquestion/<?php echo e($e->id); ?>" class="btn-sm"  style="text-decoration: none;">Add Question</a></button>
      </div>
    </div><br>

  </div>
</div>
</div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('teacher.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/zain/Online-Exam-Management-System/resources/views/questions.blade.php ENDPATH**/ ?>