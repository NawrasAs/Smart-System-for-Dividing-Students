<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="<?php echo e(asset('https://use.fontawesome.com/releases/v5.4.2/css/all.css')); ?>">
  <link rel="stylesheet" href="<?php echo e(asset('css/bootstrap.css')); ?>">
  <link rel="stylesheet" href="<?php echo e(asset('css/fonts.css')); ?>">
  <link rel="stylesheet" href="<?php echo e(asset('fonts/fonts.css')); ?>">
  <link rel="stylesheet" href="<?php echo e(asset('css/test.css')); ?>">
  <link rel="stylesheet" href="<?php echo e(asset('css/style.css')); ?>">
	<link rel="stylesheet" href="<?php echo e(asset('css/parsley.css')); ?>">
  <script type="text/javascript" src="<?php echo e(asset('js/bootstrapjquery.js')); ?>"></script>
	<script type="text/javascript" src="<?php echo e(asset('js/parsley.min.js')); ?>"></script>
  <script type="text/javascript" src="<?php echo e(asset('js/popper.js')); ?>"></script>
  <script type="text/javascript" src="<?php echo e(asset('js/bootstrap.js')); ?>"></script>

	<title>Questionnaire Management System</title>
	<link rel="icon" type="icon" href="<?php echo e(asset('icon/exam.png')); ?>">

	<style>
		.dropdown-menu li:hover{
			background-color: tomato;
		}
		.btn-block:hover{
			background-color: tomato;
		}
	</style>

</head>

<body style="background-color: whitesmoke;">

	<div class="container"><br>

      <!-- Navbar start -->

      <?php echo $__env->make('teacher.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

      <!-- nabvar end-->


      <!-- BODY Starts -->

		  <?php echo $__env->yieldContent('content'); ?>

      <!--BODY Ends -->


	</div>


	<!--Footer-->

  <?php echo $__env->make('teacher.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

	<!-- Footer End -->
<?php /**PATH /var/www/html/zain/Online-Exam-Management-System/resources/views/teacher/master.blade.php ENDPATH**/ ?>