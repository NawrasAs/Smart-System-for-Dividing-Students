      

      <?php $__env->startSection('content'); ?>
      <hr>
</div> <br><br>
        <div class="row">
            <div class="col-md-4 col-sm-4 col-xs-12"></div>
            <div class="col-md-4 col-sm-4 col-xs-12 mb-5">
                <form class="form-container" action="/fps" method="post">
                  <?php if(session('f')): ?>
                    <div class="alert alert-danger">
        							<p>Wrong Email or Password</p>
        						</div>
                  <?php endif; ?>
                    <?php echo csrf_field(); ?>
                    <h2 class="text-success text-uppercase text-center"><img class="pb-2 pr-2" src="<?php echo e(asset('icon/exam.png')); ?>" style="height: 55px;">student Login</h2>
                  <div class="form-group">
                    <label for="exampleInputEmail1" class="text-success">Give Email</label>
                    <input type="email" name="email" class="form-control" id="exampleInputEmail1" placeholder="Email" required>
                  </div><br>

                  <button type="submit" class="btn btn-success btn-block">Submit</button>
                </form>
            </div>
            <div class="col-md-4 col-sm-4 col-xs-12"></div>
        </div><br><br><br>

    </div>

    <?php $__env->stopSection(); ?>

<?php echo $__env->make('partials.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/zain/Online-Exam-Management-System/resources/views/resetpasswordS.blade.php ENDPATH**/ ?>