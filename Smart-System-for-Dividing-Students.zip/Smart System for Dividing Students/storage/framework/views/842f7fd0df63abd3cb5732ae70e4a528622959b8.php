<div class="container my-4 ">
  <hr style="border-color: mediumseagreen;">
  <div class="footer">
    <ul class="nav nav-pills nav-fill bg-success rounded">
      <li class="nav-item d-none">
        <a href="<?php echo e(route('dt')); ?>" class="nav-link text-white btn-outline-info"><i class="fab fa-connectdevelop"></i> Developers</a>
      </li>
      <li class="nav-item">
        <a href="<?php echo e(route('ct')); ?>" class="nav-link text-white btn-outline-info"><i class="far fa-copyright"></i> Copyright</a>
      </li>
      <li class="nav-item">
        <a href="<?php echo e(route('ppt')); ?>" class="nav-link text-white btn-outline-info"><i class="fas fa-user-shield"></i>  Privacy Policy</a>
      </li>
      <li class="nav-item ">
        <a href="<?php echo e(route('cot')); ?>" class="nav-link text-white btn-outline-info"><i class="fas fa-file-signature"></i>  Contact</a>
      </li>
    </ul><hr>
  </div>
</div>


</body>
</html>
<?php /**PATH /var/www/html/zain/Online-Exam-Management-System/resources/views/teacher/footer.blade.php ENDPATH**/ ?>