	

	<?php $__env->startSection('content'); ?>
	<hr style="border-color: mediumseagreen;">


		<hr><h2 class="text-success">Contact us</h2><hr>
		<p class="text-white">
			Exam_Management_System<br>
			+8801625637753 <br>
			exammanagement@gmail.com

		</p>

		<p class="text-white">
			Work/Internships<br>
			workhours :10am-10pm
		</p>

		<hr><h2 class="text-success">Tell us about your dream....</h2><hr>

		<h4 class="text-success">visit us</h4>
		<p class="text-white">via postal code<br>
			3100 Sylhet,Bangladesh
		</p>

		<h5 class="text-success">legal info</h5>
		<p class="text-white mb-5">
			exammanagementsystem@gmail.com<br>
			via- +8801521305217

		</p>

	</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('partials.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/zain/Online-Exam-Management-System/resources/views/contact.blade.php ENDPATH**/ ?>