<?php

namespace App\Relation;

use Illuminate\Database\Eloquent\Model;

class HomeCard extends Model
{
    //
}
